#modal building floors

import flet as ft


	#-----------------------------------

bldgflr_radio = ft.RadioGroup(
    content=ft.Container(
        content=ft.Column(
            controls=[
                ft.Row(spacing=50,controls=[
                    ft.Radio(value="AF",label="All Floors",),
                ]),
                ft.Row(spacing=55,controls=[
                    ft.Radio(value="GF",label="GF"),
                    ft.Radio(value="UG",label="UG"),
                ]),
                ft.Row(spacing=55,controls=[
                    ft.Radio(value="P2",label="P2"),
                    ft.Radio(value="5F",label="5F"),
                ]),
                ft.Row(spacing=55,controls=[
                    ft.Radio(value="6F",label="6F"),
                    ft.Radio(value="7F",label="7F"),
                ]),
                ft.Row(spacing=55,controls=[
                    ft.Radio(value="8F",label="8F"),
                    ft.Radio(value="9F",label="9F"),
                ]),
                ft.Row(spacing=50,controls=[
                    ft.Radio(value="10F",label="10F"),
                    ft.Radio(value="11F",label="11F"),
                ]),
            ]
    	)
    )
)

