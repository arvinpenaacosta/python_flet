import sqlite3


conn = sqlite3.connect('floormap.dat', check_same_thread=False)
cur = conn.cursor()

def initialize_db(): 
    cur.execute('''
    CREATE TABLE IF NOT EXISTS mapping(id integer primary key autoincrement,station,port,interface,floor,info1,info2)    

    ''')

# searching here
def get_by_handle(handle):
    
    #handle = "%" + handle + "%"
    print(f".2.  {handle}")
    cur.execute(
        '''
        SELECT * FROM mapping
        WHERE station LIKE ?
        ''', (handle,)
    )
    return cur.fetchall()