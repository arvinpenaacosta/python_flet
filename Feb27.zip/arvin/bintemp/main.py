from flet import *
from db import *


class Counter(UserControl):
    def __init__(self):
        super().__init__()
        

    def build(self):
        my_data = [my_data_table()]

        def my_data_table(self.data):
            print(f"Line.216- {self.data}")

        def handle_search_change(e):
            handle = search_box.value
            print(handle)
            self.results = get_by_handle(handle)
            my_data[0] = my_data_table(self.results)
            self.update()

        search_box = TextField(
            label="Search",
            width=250, height=40,
            suffix_icon=icons.SEARCH,
            on_change=handle_search_change)


        return Row([search_box])

# then use the control
def main(page):

    page.on_connect = initialize_db()




    

    page.add(
        Counter(),
        print(self.my_data)
        )

flet.app(target=main)