import flet as ft

class Chkbox:
    def __init__(self, page, plabel):
    #def build(self, page, plabel):
        self.c = ft.Checkbox(label=plabel, on_change=self.checkbox_changed)
        self.txtField = ft.TextField(width=100,  disabled=True)
        #self.txtField = ft.TextField(width=350, label=plabel, disabled=True)

        chkboxRow = ft.Column(controls=[
            ft.Row(
                controls=[
                    self.c,
                    self.txtField,
                ]
            )
        ])            

        page.add(self.c, self.txtField)
        #page.add(chkboxRow)

    def checkbox_changed(self, e):
        self.txtField.disabled = not self.c.value
        if self.c.value != True:
            self.txtField.value = ""
        else:
            self.txtField.focus()

        self.txtField.update()


def main(page):
    page.title="viNoc Tools"
    #page.window_width=800
    #page.window_height=700
    #page.bgcolor="WHITE"

    chkbox = Chkbox(page, "Change VLAN")
    #chkbox2 = Chkbox(page,"Changesdfsdf Voice")

ft.app(port=8886,target=main)

#   https://www.youtube.com/watch?v=vnb4Kiaz5tE&t=1744s


