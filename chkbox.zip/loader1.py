import flet as ft

def main(page):

    #login view logic
    def login(e):
        username = username_field.value
        password = password_field.value
        # Example of validation with hardcoded credentials
        if username == "noc" or username == "admin" and password == "MS043ms-":
            message.value = "Welcome!"
            message.color = "green"
            # Hide the login form
            username_field.visible = False
            password_field.visible = False
            login_button.visible = False
            # Call the function to add additional fields
            show_additional_fields()
        else:
            message.value = "Invalid credentials. Please try again."
            message.color = "red"
            show_banner(message.value)

    #banner event
    def show_banner(err):
        page.banner.content = ft.Text(f"{err}")
        page.banner.open = True
        page.update()  
    
    #banner event
    def close_banner(e):
        page.banner.open = False
        username_field.value = ""
        password_field.value = ""
        page.update()
    
    #banner event
    def yes_close(e):
        page.window_destroy()

    #banner view model
    page.banner = ft.Banner(
        bgcolor=ft.colors.RED_500,
        leading=ft.Icon(ft.icons.WARNING_AMBER_ROUNDED, color=ft.colors.AMBER, size=40),
        actions=[
            ft.ElevatedButton(text="Retry New Value", on_click=close_banner),
            ft.ElevatedButton(text="Cancel", on_click=yes_close),
        ],
    ) 

    #login view model
    username_field = ft.TextField(label="Username")
    password_field = ft.TextField(label="Password", password=True, on_submit=login)
    login_button = ft.ElevatedButton("Login", on_click=login)
    message = ft.Text("", color="red")
    page.add(username_field, password_field, login_button, message)
    page.update()

    
    '''
    def show_additional_fields():
        # Add additional textfields
        global textfield1, textfield2, textfield3
        textfield1 = ft.TextField(label="Additional Information 1")
        textfield2 = ft.TextField(label="Additional Information 2")
        textfield3 = ft.TextField(label="Additional Information 3")
        submit_button = ft.ElevatedButton("Submit2", on_click=submit_text_info)
        page.add(textfield1, textfield2, textfield3, submit_button)
        page.update()
    '''

    #process view model
    def show_additional_fields():
        # Add additional textfields
        global textfield1, textfield2, textfield3, checkbox
        textfield1 = ft.TextField(label="Additional Information 1")
        textfield2 = ft.TextField(label="Additional Information 2")
        textfield3 = ft.TextField(label="Additional Information 3",enabled=False)
        checkbox = ft.Checkbox(label='Enable Additional Textfield3', on_change=enable_disable_textfield3)
        submit_button = ft.ElevatedButton("Submit2", on_click=submit_text_info)
        page.add(textfield1, textfield2, checkbox, textfield3, submit_button)
        page.update()

    #checkbox logic
    def enable_disable_textfield3(e):
        if e.new_value:
            textfield3.enabled = True
        else:
            textfield3.enabled = False

    #process logic
    def submit_text_info(e):
        text_info1 = textfield1.value
        text_info2 = textfield2.value
        text_info3 = textfield3.value
        if len(text_info1) < 6 and len(text_info2) < 6:
            message.value = f"info 1: {text_info1} | info 2: {text_info2} | info 3: {text_info3}"
            page.update()
        else:
            show_banner("Additional information 1 & 2 should be greater than 6 characters.")

   
ft.app(port=8886, target=main)