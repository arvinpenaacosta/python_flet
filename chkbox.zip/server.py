from flask import Flask, request, send_file
import json

app = Flask(__name__)

@app.route('/')
def index():
    return send_file('/index.html')
    
@app.route('/submit', methods=['POST'])
def submit():
    # get form data from request
    data = request.get_json()
    value1 = data['value1']
    value2 = data['value2']
    # print form data to console
    print(f'Value 1: {value1}\nValue 2: {value2}')
    return 'Form data received'

if __name__ == "__main__":
    app.run(debug=True)
