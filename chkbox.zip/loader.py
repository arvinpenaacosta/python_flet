import flet as ft

def show_banner(page, message):
    page.banner.content = ft.Text(f"{message}")
    page.banner.open = True
    page.update()

def close_banner(e):
    page.banner.open = False
    username_field.value = ""
    password_field.value = ""
    page.update()

def yes_close(e):
    page.window_destroy()


class Login1:
    def __init__(self, page):
        self.username_field = ft.TextField(label="Username")
        self.password_field = ft.TextField(label="Password", password=True)
        self.login_button = ft.ElevatedButton("Login", on_click=self.on_login)
        self.message = ft.Text("", color="red")
        self.page = page
        self.page.add(self.username_field, self.password_field, self.login_button, self.message)

    def on_login(self, e):
        username = self.username_field.value
        password = self.password_field.value
        # Example of validation with hardcoded credentials
        if username == "admin" and password == "password":
            self.message.value = "Welcome! 1"
            self.message.color = "green"
            # Hide the login form
            self.username_field.visible = False
            self.password_field.visible = False
            self.login_button.visible = False
            # Show the additional fields
            self.additional_fields = AdditionalFields(self.page)
        else:
            self.message.value = "Invalid credentials. Please try again."
            self.message.color = "red"
            show_banner(self.page, self.message.value)
            
class Login2:
    def init(self, page):
        self.username_field = ft.TextField(label="Username")
        self.password_field = ft.TextField(label="Password", password=True)
        self.login_button = ft.ElevatedButton("Login", on_click=self.on_login)
        self.message = ft.Text("", color="red")
        self.page = page
        self.page.add(self.username_field, self.password_field, self.login_button, self.message)

    def on_login(self, e):
        username = self.username_field.value
        password = self.password_field.value
        # Example of validation with hardcoded credentials
        if username == "admin2" and password == "password2":
            self.message.value = "Welcome! 2"
            self.message.color = "green"
            # Hide the login form
            self.username_field.visible = False
            self.password_field.visible = False
            self.login_button.visible = False
            # Show the additional fields
            self.additional_fields = AdditionalFields(self.page)
        else:
            self.message.value = "Invalid credentials. Please try again."
            self.message.color = "red"
            show_banner(self.page, self.message.value)


def main(page):



    page.banner = ft.Banner(
        bgcolor=ft.colors.RED_500,
        leading=ft.Icon(ft.icons.WARNING_AMBER_ROUNDED, color=ft.colors.AMBER, size=40),
        actions=[
            ft.ElevatedButton(text="Retry New Value", on_click=close_banner),
            ft.ElevatedButton(text="Cancel", on_click=yes_close),
        ],
    )

    login = Login1(page)


ft.app(port=8886, target=main)



