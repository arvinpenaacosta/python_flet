# Flet School app WITH SQlite3 CRUD BAsic

## if You Get Error fisrt run Flet Because You Not Create Table
## run myaction.py before flet main.py
## run with command python3 myaction.py for create YOu Table SQlite 
