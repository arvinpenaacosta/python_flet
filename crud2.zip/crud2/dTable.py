import flet 
from flet import *

def main(page: Page):
    page.window_width=500
    page.window_height=400

    mytable =  DataTable(
        columns=[
            DataColumn(Text("First name")),
            DataColumn(Text("Last name")),
            DataColumn(Text("Age"), numeric=True),
        ],
        # THIS IS YOU ROW OF YOU TABLE
        
        rows=[]
 
        )

    
    mytable.rows.append(
            DataRow(
            cells=[
                # THIS FOR ID THE YOU TABLE 
                DataCell(Text(len(mytable.rows))),
                DataCell(Text(name.value)),
                DataCell(Text(address.value)),
            ],
        
            on_select_changed=lambda e:editindex(e.control.cells[0].content.value,e.control.cells[1].content.value)
                )
 
            ) 






    

    page.add(
        DataTable(
            columns=[
                DataColumn(Text("First name")),
                DataColumn(Text("Last name")),
                DataColumn(Text("Age"), numeric=True),
            ],

            rows=[
                DataRow(
                    cells=[
                        DataCell(Text("John")),
                        DataCell(Text("Smith")),
                        DataCell(Text("43")),
                    ],
                ),
                DataRow(
                    cells=[
                        DataCell(Text("Jack")),
                        DataCell(Text("Brown")),
                        DataCell(Text("19")),
                    ],
                ),
                DataRow(
                    cells=[
                        DataCell(Text("Alice")),
                        DataCell(Text("Wong")),
                        DataCell(Text("25")),
                    ],
                ),
            ],
        ),
    )



flet.app(target=main)